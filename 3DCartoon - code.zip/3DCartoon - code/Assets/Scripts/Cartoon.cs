using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cartoon : MonoBehaviour
{
    public Transform cartoon;
    public float xMove;
    public float yMove;
    public float xRotate;
    public float yRoate;



    public void Quit()
    {
        Application.Quit();
    }

    public void Reset()
    {
        xMove = 0;
        yMove = 0;
        xRotate = 0;
        yRoate = 0;
        SetTransform();
    }

    public void MoveLeft()
    {
        xMove -= 1;
        SetTransform();
    }
    public void MoveRight()
    {
        xMove += 1;
        SetTransform();
    }
    public void MoveDown()
    {
        yMove -= 1;
        SetTransform();
    }
    public void MoveUp()
    {
        yMove += 1;
        SetTransform();
    }

    public void RotateXPos()
    {
        xRotate += 5;
        SetTransform();
    }

    public void RotateXNeg()
    {
        xRotate -= 5;
        SetTransform();
    }


    public void RotateYPos()
    {
        yRoate += 5;
        SetTransform();
    }

    public void RotateYNeg()
    {
        yRoate -= 5;
        SetTransform();
    }
    
    

    void SetTransform()
    {
        cartoon.position = new Vector3(xMove, yMove, 0);
        cartoon.localEulerAngles = new Vector3(yRoate, xRotate, 0);
        //cartoon.Rotate(new Vector3(yRoate,xRotate,0));
    }
    
}
